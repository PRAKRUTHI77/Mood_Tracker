# Mood Tracker – Local build & run

## Prerequisites
- Node.js v18+ and npm

## Project Structure
- server.js : Express server
- package.json : Dependencies and scripts
- data/moods.ndjson : Flat-file storage (JSON objects per line)
- public/ : Static frontend (form + charts)
- BUILD.md : Build/run instructions

## Install
cd ctrl-alt-elite/cd application
npm install

## Run
npm start
# open http://localhost:3000 in your browser

## Test
1. Add a few entries in the form.
2. Click "Show Report" to see averages and charts.
3. Confirm entries are saved in data/moods.ndjson.

## Build
No separate build required (Node.js + static files).

## Restore
- Run npm install to restore dependencies.

## Submission
- Zip the entire ctrl-alt-elite/ folder.
- Exclude node_modules/ to keep size small.
- Final file name format: FullName_ctrl-alt-elite.zip
-