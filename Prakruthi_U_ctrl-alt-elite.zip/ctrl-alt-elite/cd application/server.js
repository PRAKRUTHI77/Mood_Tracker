const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// data file path
const DATA_DIR = path.join(__dirname, 'data');
const FILE = path.join(DATA_DIR, 'moods.ndjson');

// ensure data directory and file exist
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, '');

// middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// add entry (O(1) append)
app.post('/api/entries', (req, res) => {
  const rec = req.body || {};
  const required = ['date','sleep','stress','symptoms','mood','engagement'];
  for (const k of required) {
    if (!(k in rec)) return res.status(400).json({ error: `Missing: ${k}` });

  }
  try {
    fs.appendFileSync(FILE, JSON.stringify(rec) + '\n', 'utf8');
    return res.json({ ok: true });
  } catch {
    return res.status(500).json({ error: 'Write failed' });
  }
});

// get all entries (O(n))
app.get('/api/entries', (_req, res) => {
  try {
    const text = fs.readFileSync(FILE, 'utf8');
    const lines = text.split('\n').filter(Boolean);
    const entries = [];
    for (const line of lines) {
      try { entries.push(JSON.parse(line)); } catch {}
    }
    return res.json(entries);
  } catch {
    return res.status(500).json({ error: 'Read failed' });
  }
});

// start server
app.listen(PORT, () => {
  console.log(`Mood Tracker running at http://localhost:${PORT}`);
});