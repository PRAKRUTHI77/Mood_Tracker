const $ = (sel) => document.querySelector(sel);

async function postJSON(url, data) {
  const r = await fetch(url, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data),
  });
  return r.json();
}

async function getJSON(url) {
  const r = await fetch(url);
  return r.json();
}

$('#entryForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = {
    date: fd.get('date'),
    sleep: Number(fd.get('sleep')),
    stress: Number(fd.get('stress')),
    symptoms: Number(fd.get('symptoms')),
    mood: Number(fd.get('mood')),
    engagement: Number(fd.get('engagement')),
    drugs: (fd.get('drugs') || '').trim(),
    notes: (fd.get('notes') || '').trim(),
  };
  const res = await postJSON('/api/entries', payload);
  $('#saveStatus').textContent = res.ok ? 'Saved ✅' : ('Failed ❌ ' + (res.error || ''));
  if (res.ok) e.target.reset();
});

let charts = [];
function destroyCharts() {
  for (const c of charts) c.destroy();
  charts = [];
}

function avg(arr) {
  if (!arr.length) return 0;
  let s = 0;
  for (const x of arr) s += x;
  return s / arr.length;
}

$('#refreshBtn').addEventListener('click', async () => {
  const entries = await getJSON('/api/entries');

  entries.sort((a,b) => (a.date||'').localeCompare(b.date||''));

  const dates = entries.map(e => e.date);
  const sleep = entries.map(e => Number(e.sleep));
  const stress = entries.map(e => Number(e.stress));
  const mood   = entries.map(e => Number(e.mood));

  $('#metrics').innerHTML = `
    <div>Avg Sleep: <b>${avg(sleep).toFixed(2)}</b> hrs</div>
    <div>Avg Stress: <b>${avg(stress).toFixed(2)}</b></div>
    <div>Avg Mood: <b>${avg(mood).toFixed(2)}</b></div>
    <div>Total Days: <b>${entries.length}</b></div>
  `;

  destroyCharts();

  // Mood over time
  charts.push(new Chart(document.getElementById('moodOverTime'), {
    type: 'line',
    data: { labels: dates, datasets: [{ label: 'Mood', data: mood }] }
  }));

  // Sleep vs Stress
  charts.push(new Chart(document.getElementById('sleepStress'), {
    type: 'bar',
    data: {
      labels: dates,
      datasets: [
        { label: 'Sleep (hrs)', data: sleep },
        { label: 'Stress (1–10)', data: stress }
      ]
    }
  }));
});